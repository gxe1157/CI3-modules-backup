<div class="col-md-10 col-md-offset-1" style="text-align: center;">
    <a href="<?php echo base_url().'cart/go_to_checkout/'.$checkout_token; ?>">
    <button class="btn btn-danger" name="submit" value="Submit" type="button">
        <span class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span> 
        Go To Checkout
    </button></a>
</div>