<?php
echo Modules::run('enquiries/_draw_customer_inbox', $customer_id);
?>