<h1><?= $headline ?></h1>
<p>Your message has been successfully sent.  Thank you!</p>