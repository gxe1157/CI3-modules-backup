<h1>Welcome to the admin panel.</h1>

<p>
    <?php
    echo anchor('dvilsf/logout', 'Logout');
    ?>
</p>